# noun_compound_classification

Please read report.pdf